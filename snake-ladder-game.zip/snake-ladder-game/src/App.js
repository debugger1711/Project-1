import React from 'react';
import SnakeLadderGame from './components/SnakeLadderGame';
export default function App(){return <SnakeLadderGame/>;}